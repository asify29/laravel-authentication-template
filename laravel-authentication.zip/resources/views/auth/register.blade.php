@extends('layouts.auth')

@section('content')
<div class="limiter">
        <div class="container-login100" style="background-image: url('{{asset('auth/images/bg-01.jpg')}}');">
            <div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
                <form class="login100-form validate-form" method="POST" action="{{ route('register') }}" autocomplete="off">
                    {{ csrf_field() }}
                    <span class="login100-form-title p-b-49">
                        Create New Account
                    </span>

                    <div class="wrap-input100 validate-input m-b-23{{ $errors->has('name') ? ' has-error' : '' }}" data-validate = "Username is reauired">
                        <span class="label-input100">Username</span>
                        <input class="input100" type="text" name="name" placeholder="Type your username" value="{{ old('name') }}" required autofocus>
                        <span class="focus-input100" data-symbol="&#xf206;"></span>
                        @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                        @endif
                    </div>

                    <div class="wrap-input100 validate-input m-b-23{{ $errors->has('email') ? ' has-error' : '' }}" data-validate = "E-mail is reauired">
                        <span class="label-input100">E-mail</span>
                        <input class="input100" type="email" name="email" placeholder="Type your email" value="{{ old('email') }}" required>
                        <span class="focus-input100" data-symbol="&#xf206;"></span>
                        @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                        @endif
                    </div>

                    <div class="wrap-input100 validate-input{{ $errors->has('password') ? ' has-error' : '' }}" data-validate="Password is required">
                        <span class="label-input100">Password</span>
                        <input class="input100" type="password" name="password" placeholder="Type your password" required>
                        <span class="focus-input100" data-symbol="&#xf190;"></span>
                        @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                        @endif
                    </div>
                    
                    <div class="wrap-input100 validate-input" data-validate="Password is required">
                        <span class="label-input100">Confirm Password</span>
                        <input class="input100" type="password" name="password_confirmation" required>
                        <span class="focus-input100" data-symbol="&#xf190;"></span>
                    </div>
                    <div class="container-login100-form-btn p-t-30">
                        <div class="wrap-login100-form-btn">
                            <div class="login100-form-bgbtn"></div>
                            <button class="login100-form-btn">
                                Register
                            </button>
                        </div>
                    </div>

                    <div class="flex-col-c p-t-155">
                        <a href="{{route('login')}}" class="txt2">
                            Back To Login
                        </a>
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
@endsection
