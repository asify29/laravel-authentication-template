@extends('layouts.auth')

@section('content')
<div class="limiter">
        <div class="container-login100" style="background-image: url('{{asset('auth/images/bg-01.jpg')}}');">
            <div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
                <form class="login100-form validate-form" method="POST" action="{{ route('password.email') }}">
                        {{ csrf_field() }}
                    <span class="login100-form-title p-b-49">
                        Password Reset Request
                    </span>

                    <div class="wrap-input100 validate-input m-b-23">
                        <span class="label-input100">E-mail</span>
                        <input class="input100" type="text" name="email" placeholder="Type your email" value="{{ old('email') }}" required>
                        <span class="focus-input100" data-symbol="&#xf206;"></span>
                        @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                        @endif
                    </div>
                    <div class="container-login100-form-btn">
                        <div class="wrap-login100-form-btn">
                            <div class="login100-form-bgbtn"></div>
                            <button class="login100-form-btn">
                                 Send Password Reset Link
                            </button>
                        </div>
                    </div>

                    <div class="flex-col-c p-t-155">
                        
                        <a href="{{route('login')}}" class="txt2">
                            Back To Login
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
@endsection
